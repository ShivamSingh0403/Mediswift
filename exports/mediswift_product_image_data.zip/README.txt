========================================================================
MEDISWIFT 2.0 - PRODUCT IMAGE AUDIT, DISCOVERY & COMPLIANCE DATA PACKAGE
========================================================================
Generated on: 2026-09-12 16:31:00 UTC
Catalog Size: 512 pharmaceutical and healthcare products

DIRECTORY STRUCTURE
-------------------
mediswift_product_image_data.zip
├── README.txt                                (This documentation)
├── image_discovery_report.json               (Machine-readable catalog metrics)
├── audit_reports/
│   ├── all_products_image_audit.csv          (Full catalog audit with SKU, status, & license)
│   ├── verified_images.csv                   (Verified images with SHA-256 and auditor)
│   ├── pending_review_images.csv             (Images downloaded and awaiting visual verification)
│   ├── missing_images.csv                    (Products using MediSwift clinical placeholder)
│   ├── rejected_images.csv                   (Images rejected during compliance audit)
│   ├── discovered_candidates.csv             (Web discovery candidates with confidence scores)
│   ├── rights_unknown_candidates.csv         (Candidates requiring license/permission clearance)
│   ├── product_mismatch_candidates.csv       (Candidates flagged for dosage or strength divergence)
│   └── duplicate_images.csv                  (Candidates flagged for identical image hashes)
└── images/
    ├── verified/                             (Approved and verified packshot photos)
    ├── pending_review/                       (Downloaded candidates pending manual sign-off)
    ├── rejected/                             (Archived rejected assets)
    └── placeholders/                         (Custom SVG/PNG placeholders for unverified products)

REGULATORY & ACCURACY COMPLIANCE
--------------------------------
1. No AI-generated pharmaceutical packaging is permitted.
2. No random internet or Google Images scraping.
3. Every candidate is matched strictly against product name, brand, dosage strength, and form.
4. If rights are unconfirmed, candidate is marked RIGHTS_UNKNOWN: "Usage permission has not been confirmed."
5. If strength or pack size differs from catalog, candidate is marked PRODUCT_MISMATCH.
6. Only authorized clinical placeholders are displayed for products lacking verified images.
========================================================================
